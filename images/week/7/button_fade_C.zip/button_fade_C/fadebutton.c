#include <avr/io.h>
#include <util/delay.h>



int main(void)
{
//SETUP
//Button is on PA3
//LED is PA7
  uint8_t fade_out = 0;
#define BIAS_MAX 600
#define BIAS_MIN 1
uint16_t bias = BIAS_MIN;
	
PORTA= _BV(PA7); //Turn button pullup resistor on
DDRB = _BV(PB2); //Enable output on the LED pin
//PORTB = _BV(PB2); //Turns LED on

//LOOP
while (1)
{
if ((PINA & _BV(PA7))) //button is not pushed
{
PORTB = 0; //turn LED off
}
else 
while (1){
PORTB |= (1 << _BV(PB2)); //turn LED on
_delay_loop_2(bias);
PORTB &= ~(1 << _BV(PB2));
_delay_loop_2(BIAS_MAX - bias);

if (fade_out == 0) {
  bias++;
  if (bias >= BIAS_MAX - 1) fade_out = 1;
}
else {
  bias--;
  if (bias <= BIAS_MIN) fade_out = 0;
}


}
return (0);
}
}
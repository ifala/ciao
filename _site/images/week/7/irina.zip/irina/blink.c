#include <avr/io.h>
#include <util/delay.h>



#define bit_get(p,m) ((p) & (m)) 

#define bit_set(p,m) ((p) |= (m)) 

#define bit_clear(p,m) ((p) &= ~(m)) 

#define BIT(x) (0x01 << (x)) 
int main()
{
//SETUP
//Button is on PA3--PA7
//LED is PB2--

bit_set(PORTA,BIT(7)); //Turn button pullup resistor on by setting PA3(input) high

bit_set(DDRB,BIT(2)); //Enable output on the LED pin (PB2)





//LOOP
while (1)
{
if(bit_get(PINA,BIT(7)))//button is not pushed
{
bit_set(PORTB,BIT(0));//LED is on

}
else // button is pushed
{
bit_set(PORTB,BIT(2));//LED is on
_delay_ms(50);
bit_clear(PORTB,BIT(2));//LED is off
_delay_ms(2);
bit_set(PORTB,BIT(2));//LED is on
_delay_ms(50);
bit_clear(PORTB,BIT(2));//LED is off
_delay_ms(2);
bit_set(PORTB,BIT(2));//LED is on
_delay_ms(50);
bit_clear(PORTB,BIT(2));//LED is off
_delay_ms(2);
bit_set(PORTB,BIT(2));//LED is on
_delay_ms(50);
bit_clear(PORTB,BIT(2));//LED is off
_delay_ms(2);
bit_set(PORTB,BIT(2));//LED is on
_delay_ms(50);
bit_clear(PORTB,BIT(2));//LED is off
_delay_ms(2);
}
} 

}
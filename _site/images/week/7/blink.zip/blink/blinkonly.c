#include <avr/io.h>
#include <util/delay.h>

#define TRUE 1
#define FALSE 0

int main()
{
//SETUP
//Button is on PA3
//LED is PA7

PORTA= _BV(PA7); //Turn button pullup resistor on
DDRB = _BV(PB2); //Enable output on the LED pin
//PORTB = _BV(PB2); //Turns LED on

//LOOP
while (TRUE)
{
if ((PINA & _BV(PA7))) //button is not pushed
{
PORTB = 0; //turn LED off
}
else 
{
PORTB = _BV(PB2); //turn LED on
_delay_ms(10);
PORTB = 0;
_delay_ms(100);
}
}
}

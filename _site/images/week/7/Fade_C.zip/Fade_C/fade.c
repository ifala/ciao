#include <avr/io.h>
#include <util/delay.h>
#define LED1_PORT PB2
int main(void) {
  // Set the LED port number as output.
  DDRB |= (1 << LED1_PORT);
  uint8_t fade_out = 0;
#define BIAS_MAX 600
#define BIAS_MIN 1
  uint16_t bias = BIAS_MIN;
  // Begin an infinite loop. This is how most programs work.
  while (1) {
    // Set the LED port bit to "1" - LED will be turned on.
    PORTB |= (1 << LED1_PORT);
    // Wait a little. The delay function simply does N-number of "empty" loops.
    _delay_loop_2(bias);
    // Set the LED port bit to "0" - LED will be turned off.
    PORTB &= ~(1 << LED1_PORT);
    // Wait a little.
    _delay_loop_2(BIAS_MAX - bias);
    if (fade_out == 0) {
      bias++;
      if (bias >= BIAS_MAX - 1) fade_out = 1;
    }
    else {
      bias--;
      if (bias <= BIAS_MIN) fade_out = 0;
    }
    // Do that again ...
  }
  // Return the mandatory for the "main" function value.
  return (0);
}
//
// Tiny Midi
//
//

#include <avr/io.h>
#include <util/delay.h>

#define output(directions,pin) (directions |= pin) // set port direction for output

#define set(port,pin) (port |= pin) // set port pin
#define clear(port,pin) (port &= (~pin)) // clear port pin
#define pin_test(pins,pin) (pins & pin) // test for port pin
#define bit_test(byte,bit) (byte & (1 << bit)) // test for bit set
#define bit_delay_time 100 // bit delay for 9600 with overhead
#define bit_delay() _delay_us(bit_delay_time) // RS232 bit delay
#define half_bit_delay() _delay_us(bit_delay_time/2) // RS232 half bit delay
#define charge_delay_1() _delay_us(1) // charge delay 1
#define charge_delay_2() _delay_us(10) // charge delay 2
#define charge_delay_3() _delay_us(100) // charge delay 3
#define settle_delay() _delay_us(100) // settle delay
#define char_delay() _delay_ms(10) // char delay

#define serial_port PORTB
#define serial_direction DDRB
#define serial_pin_out (1 << PB0)
#define charge_port PORTB
#define charge_direction DDRB
#define charge_pin (1 << PB2)

#define sense_port PORTA
#define sense_direction DDRA

#define ref (0 << REFS1) | (0 << REFS0) // reference voltage

#define sense0 (1 << MUX2) | (1 << MUX1) | (1 << MUX0) // PA7
#define sense1 (1 << MUX2) | (1 << MUX1) | (0 << MUX0) // PA6
#define sense2 (1 << MUX2) | (0 << MUX1) | (1 << MUX0) // PA5
#define sense3 (1 << MUX2) | (0 << MUX1) | (0 << MUX0) // PA4
#define sense4 (0 << MUX2) | (1 << MUX1) | (1 << MUX0) // PA3
#define sense5 (0 << MUX2) | (1 << MUX1) | (0 << MUX0) // PA2
#define sense6 (0 << MUX2) | (0 << MUX1) | (1 << MUX0) // PA1
#define sense7 (0 << MUX2) | (0 << MUX1) | (0 << MUX0) // PA0

#define down_threshold 500
#define up_threshold 550


void put_char(volatile unsigned char *port, unsigned char pin, char txchar) {
	//
	// send character in txchar on port pin
	//	 assumes line driver (inverts bits)
	//
	// start bit
	//
	clear(*port,pin);
	bit_delay();
	//
	// unrolled loop to write data bits
	//
	if bit_test(txchar,0)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,1)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,2)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,3)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,4)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,5)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,6)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	if bit_test(txchar,7)
		set(*port,pin);
	else
		clear(*port,pin);
	bit_delay();
	//
	// stop bit
	//
	set(*port,pin);
	bit_delay();
	//
	// char delay
	//
	bit_delay();
}

int check_pin(unsigned char pin) {
	unsigned char up_lo,up_hi,down_lo,down_hi;
	int up_value, down_value, value;
	
	//
	// set the A/D pin
	//
	ADMUX = ref | pin;
	
	//
	// settle, charge, and wait 1
	//
	settle_delay();
	set(charge_port, charge_pin);
	charge_delay_1();
	//
	// initiate conversion
	//
	ADCSRA |= (1 << ADSC);
	//
	// wait for completion
	//
	while (ADCSRA & (1 << ADSC))
		;
	//
	// save result
	//
	up_lo = ADCL;
	up_hi = ADCH;
	//
	// settle, discharge, and wait 1
	//
	settle_delay();
	clear(charge_port, charge_pin);
	charge_delay_1();
	//
	// initiate conversion
	//
	ADCSRA |= (1 << ADSC);
	//
	// wait for completion
	//
	while (ADCSRA & (1 << ADSC))
		;
	//
	// save result
	//
	down_lo = ADCL;
	down_hi = ADCH;
	//
	// process result
	//
	up_value = 256 * up_hi + up_lo;
	down_value = 256 * down_hi + down_lo;
	value = (up_value + (1023 - down_value)) / 2;
	
	return value;
}

void sense_pin(unsigned char pin, int *oldValue, char labelChar) {
	
		
	int value = check_pin(pin);

		
	
	if ((*oldValue == 1 && value > up_threshold) || (*oldValue == 0 && value < down_threshold)) {
		put_char(&serial_port, serial_pin_out, labelChar);
		put_char(&serial_port, serial_pin_out, '=');
		char_delay();
		if (*oldValue) {
			*oldValue = 0;
			put_char(&serial_port, serial_pin_out, '0');
		}
		else {
			*oldValue = 1;
			put_char(&serial_port, serial_pin_out, '1');
		}
		char_delay();
		put_char(&serial_port, serial_pin_out, '\n');
		char_delay();
	}
}

int main(void) {
	
	static int touch0=0,touch1=0,touch2=0,touch3=0,touch4=0,touch5=0,touch6=0,touch7=0;
	
	//
	// set clock divider to /1
	//
	CLKPR = (1 << CLKPCE);
	CLKPR = (0 << CLKPS3) | (0 << CLKPS2) | (0 << CLKPS1) | (0 << CLKPS0);
	//
	// initialize output pins and print 'a'
	//
	set(serial_port, serial_pin_out);
	output(serial_direction, serial_pin_out);
	
	clear(charge_port, charge_pin);
	output(charge_direction, charge_pin);	
	//
	// init A/D
	//
	ADMUX = ref; // Vcc ref
	ADCSRA = (1 << ADEN) // enable
		| (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); // prescaler /128
	ADCSRB = (0 << ADLAR); // right adjust
	
	
	
	
	while (1) {
		
		
		
		sense_pin(sense0, &touch0, '0');
		sense_pin(sense1, &touch1, '1');
		sense_pin(sense2, &touch2, '2');
		sense_pin(sense3, &touch3, '3');
		sense_pin(sense4, &touch4, '4');
		sense_pin(sense5, &touch5, '5');
		sense_pin(sense6, &touch6, '6');
		sense_pin(sense7, &touch7, '7');
	}
}